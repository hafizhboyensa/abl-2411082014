package com.hafizh.order.entity;

import java.util.Date;
import jakarta.persistence.*;

@Entity
@Table(name = "orders")
public class Orders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long produkId;
    private Long pelangganId;
    private Date tglTrans;
    private int jumlah;
    private double total;

    public Orders() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getProdukId() { return produkId; }
    public void setProdukId(Long produkId) { this.produkId = produkId; }
    public Long getPelangganId() { return pelangganId; }
    public void setPelangganId(Long pelangganId) { this.pelangganId = pelangganId; }
    public Date getTglTrans() { return tglTrans; }
    public void setTglTrans(Date tglTrans) { this.tglTrans = tglTrans; }
    public int getJumlah() { return jumlah; }
    public void setJumlah(int jumlah) { this.jumlah = jumlah; }
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
}