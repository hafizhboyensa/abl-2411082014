package com.hafizh.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.hafizh.order.entity.Orders;
import com.hafizh.order.repository.OrderRepository;
import com.hafizh.order.vo.OrderVO;
import com.hafizh.order.vo.PelangganVO;
import com.hafizh.order.vo.ProdukVO;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    private final RestClient restClient;

    public OrderService(RestClient restClient) {
        this.restClient = restClient;
    }

    public List<Orders> getAllOrder() {
        return orderRepository.findAll();
    }

    public Orders getOrderById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }

    public OrderVO saveOrder(Orders order) {

    // Cek Pelanggan
    PelangganVO pelanggan = getPelanggan(order.getPelangganId());

    if (pelanggan == null) {
        throw new RuntimeException("Pelanggan tidak ditemukan");
    }

    // Cek Produk
    ProdukVO produk = getProduk(order.getProdukId());

    if (produk == null) {
        throw new RuntimeException("Produk tidak ditemukan");
    }

    // Ambil harga Produk dan Menghitung total
    double total = produk.getHarga() * order.getJumlah();

    order.setTotal(total);

    Orders savedOrder = orderRepository.save(order);

    // Simpan Order
    return getOrderVO(savedOrder);
}

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    public Orders updateOrder(Long id, Orders orders) {
        Orders existing = orderRepository.findById(id).orElse(null);
        if (existing != null) {
            existing.setProdukId(orders.getProdukId());
            existing.setPelangganId(orders.getPelangganId());
            existing.setTglTrans(orders.getTglTrans());
            existing.setJumlah(orders.getJumlah());
            existing.setTotal(orders.getTotal());
            return orderRepository.save(existing);
        }
        return null;
    }

    // Mengambil Data Pelanggan

    public PelangganVO getPelanggan(Long id) {

        return restClient.get()
                .uri("http://localhost:8081/api/pelanggan/" + id)
                .retrieve()
                .body(PelangganVO.class);
    }

    // Mengambil Data Produk

    public ProdukVO getProduk(Long id) {

        return restClient.get()
                .uri("http://localhost:8082/api/produk/" + id)
                .retrieve()
                .body(ProdukVO.class);
    }

    public OrderVO getOrderVO(Orders order) {

        PelangganVO pelanggan = getPelanggan(order.getPelangganId());
        ProdukVO produk = getProduk(order.getProdukId());

        OrderVO orderVO = new OrderVO();

        orderVO.setId(order.getId());
        orderVO.setProdukId(order.getProdukId());
        orderVO.setPelangganId(order.getPelangganId());
        orderVO.setJumlah(order.getJumlah());
        orderVO.setTglTrans(order.getTglTrans());
        orderVO.setTotal(order.getTotal());

        orderVO.setPelanggan(pelanggan);
        orderVO.setProduk(produk);

        return orderVO;
    }

}